
<?php 
 error_reporting(0);
 ini_set('display_errors', 0);
//------------------------------------------------------------------------------------------------
// create variable for storing user information form signeup form
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$password=$_POST['password'];
$conform=$_POST['conform'];
if(isset($_POST['submit']))
{
        $conn=mysqli_connect("localhost","root","","signeup");
        $sql = "SELECT * from signeup_table WHERE Email='$email'";
        $result = mysqli_query($conn, $sql);
        $num = mysqli_num_rows($result); 
        if($num==0){
                if($password===$conform){
                        $query="INSERT INTO signeup_table(FirstName, LastName, Email, Password, ConformPassword) VALUES('$firstname','$lastname','$email','$password','$conform')";
                        $result=mysqli_query($conn,$query);               // send one  infromation to signeup file
                        $host  = $_SERVER['HTTP_HOST'];
                        $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');                                            
                        if($result){  header("location:http://$host$uri/$extra"); }
                                      
                }
                // else{echo '<script>alert("Pleas check Conform Password")</script>';}
                //end of conform password method

        }//end of insert new data
        else{
                echo '<script>alert("email is already exist")</script>';
        }
        //end of email exist or not if condition and else condition


}//end of isset button if condition


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../bootstrap.css">
    <link rel="stylesheet" href="../fontawesome-free-5.15.4-web/css/all.min.css">
    <link rel="stylesheet" href="signeup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <script src="../jquery_path.js"></script>


</head>
<body>

    <header>
        <nav>
            <div class="community-heading">
                Tip community
            </div>
        </nav>
    </header>
    
    <!-- signe up alert box -->
    <div class="alert-box" id="alert-box">
       <div class="message"><i class="fa fa-check"></i><p>signeup successfully</p></div>
       <div class="close-alert"><i class="fa fa-times"></i></div>
    </div><!--end of alert box -->



    <main>
        <section class="input-section">
            <div class="suggetion">
                <div class="heading">signeup to tip community</div>
               <div class="signeup-mssg">already you have an acccount ?<a onclick="login_page()">log in</a> </div>
            </div><!--end of suggetion div-->
            <div class="inputs">
                <form action=" " method="POST">    
                <input type="text" id="firstname" placeholder="first name" name="firstname" placeholder="first name"  required  >           
                <input type="text" placeholder="last name" id="lastname" name="lastname" required  >
                <input type="email" name="email" id="email" required  placeholder="email"  >
                <input type="password" id="password" name="password"  placeholder="password" required ">
                <input type="password" name="conform" id="conform" required  placeholder="conform-password">
                 
                <div class="message">
                    <input type="checkbox" id="checkbox">
                    <label for="checkbox">you have read and agree terms & service</label>
                </div><!--end of check message section-->

                <div class="button"><button id="submit-btn" type="submit" class="primery" name="submit">register</button></div>     

            </form>
            </div><!--end of inputs-->
        </section><!--end of input section-->
    </main>
    

    <script>
        var alert_box=document.getElementById("alert-box");
        var conform_field=document.getElementById("conform-password");
        function hindi_lan(){
            window.location.href="signeup_hindi.php";
        }

        //go to login page
        function login_page(){
            window.location.href="../login/login.php";
        }
        
        //checkin user signeup or not

        // function close_alert(){
        //     alert_box.style.display="none";
        // }




        // if($conform){

        //     echo 'console.log("field)';
        // }
        // ?>

     

    </script>
    <!-- data base working file fatch data  -->
</body>
</html>