var email=document.getElementById("email");
var password=document.getElementById("password");
//go to signe up page
    function signeup(){
    window.location.href="../signeup/signeup.php";
    }

    window.addEventListener("load",function(){

        email.value=" ";
        password.value=" ";
    });

   


//clear 
