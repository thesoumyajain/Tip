<?php
 error_reporting(0);
 ini_set('display_errors', 0);
 session_start();
// $result=false;
// $arr=$_GET;
// $result=$arr['login_false'];


//------------------------------------------------------------------------------------------

   $email=$_POST['email'];
   $password=$_POST['password'];
   session_start();
    if(isset($_POST['submit'])){
        $conn=mysqli_connect("localhost","root","","signeup");
        $query="SELECT * FROM signeup_table WHERE Email='$email'";
        $result=mysqli_query($conn,$query);
        $exist=mysqli_num_rows($result);
        if($exist==0)
    {
            $host  = $_SERVER['HTTP_HOST'];
            $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
            $extra = 'login.php';
            echo '<script>alert("Invalid Email")</script>';
            // header("location:http://$host$uri/$extra");
        //  header("location:login.php?success=".true."&email=".$email);
    }//email checking if condtion 

    else{
        $row=mysqli_fetch_assoc($result);
        if($password===$row['Password'])
        {
            $host  = $_SERVER['HTTP_HOST'];
            $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
            $extra = '../internship_form/intern.php';
            $_SESSION['username']=$row['FirstName'];
            header("location:http://$host$uri/$extra");
            
        }else{$password_value=true;echo '<script>alert("Invalid Password")</script>';}
       
    
    }//end of else

}//end of submit button



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="../bootstrap.css">

    <script src="../jquery_path.js"></script>
    <script src="login.js"></script>
    <?php include "login_css.php"; ?>
</head>
<body>

   
<header>
        <nav>
            <div class="community-heading" style=" font-size: 40px;color: #c30f96;   font-family: 'Anton', sans-serif;  text-transform: capitalize;letter-spacing: 1px;">
                Tip community
            </div>
        </nav>
</header>

    
<!--     
    <div class="alert-box" id="alert-box">
       <div class="message"><i class="fa fa-check"></i><p>signeup successfully</p></div>
       <div class="close-alert"><i class="fa fa-times"></i></div>
    </div> end of alert box -->


    <main>
        <section class="input-section">
            <div class="suggetion">
                <div class="heading">login to tip community</div>
               <div class="signeup-mssg">dont you have an account ?<a onclick="signeup()">signe up</a> </div>

               <div class="alert-mssg">YOU NEED TO SIGN IN OR SIGN UP BEFORE CONTINUING.</div>
            </div><!--end of suggetion div-->
            <div class="inputs">

                <form action=" " method="POST" autocomplete="off" id="add_form">
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-envelope-o"></i></span>
                    <input type="email" id="email" name="email" class="form-control" placeholder="email" aria-label="Username" aria-describedby="basic-addon1">
                </div>
                

                

                <div class="input-group mb-1">
                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-unlock-alt"></i></span>
                    <input type="password" id="password" name="password" class="form-control" placeholder="password" aria-label="Username" aria-describedby="basic-addon1">
                </div>
            <?php 

                // if($result)
                // {
                //     echo '<div id="error-msg" >invalid email and password</div>'; 
                // }

            ?>
          

                <div class="button"><button id="submit-btn" type="submit" name="submit" onclick="clear_input()">Continue</button></div>     

                <!-- <div class="forgot"><a href="#" id="forgot-pass">forgot your password ?</a></div> -->
            </form>
            </div><!--end of inputs-->
        </section><!--end of input section-->
    </main>
    

<!-- java script code -------------------------------------------------->

</body>
</html>