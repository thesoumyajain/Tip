<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        *{
    margin: 0;padding: 0;
}
body{
    width: 100%;
    height: 100vh;
}
header{
    width: 100%;
    height: 100px;
}
header nav{
    width: 100%;height: 100px;
    box-shadow: 10px 10px 10px #eee;
    display: flex;
    align-items: center;
    justify-content: center;
    
}



.alert-box{
    width: 100%;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    background-color: #0f5132c0;
    display: none;

}
.alert-box .message {
    display: flex;
    margin-left: 50px;
  }
.alert-box .message p{
    text-transform: capitalize;
    font-size: 19px;
    color: rgb(255, 255, 255);
}

.alert-box .message i{
    font-size: 25px;
    color: rgb(60, 247, 36);
    margin-right: 10px;
}

.alert-box .close-alert{
    margin-right: 30px;
}
.alert-box .close-alert i{
    font-size: 30px;
    
}


/* end of navbar section designe */

/* signeup form designing */
main{
    width: 80%;
    height: 100vh;
    margin: auto;
}
main > .input-section{
    width: 500px;
    height: 550px;
    margin: auto;
    margin-top:40px;
}

main > .input-section > .suggetion{
    width: 100%;
    height: 80px;
    margin: auto;
    text-align: center;
}
main > .input-section > .suggetion > .heading{
    /* font-size: 30px;
    font-family: "EncodeSansCondensed", "EncodeSansNarrow", "Helvetica Neue", Helvetica, Arial, sans-serif;
    /* font-weight: bolder; */
    font-family:regular400;
    text-transform: capitalize;
    font-size: 30px;
    font-weight: 700;
    line-height: 1.2em;
    text-align: center;
    color: #444;

}
main > .input-section > .suggetion > .signeup-mssg{
    font-size: 16px;
    text-transform: capitalize;
    margin-top: 10px;
    font-weight: lighter;
}
main > .input-section > .suggetion > .signeup-mssg > a{
    font-size: 16px;
    color: #000;
    font-weight: 700;
    padding-left: 4px;
    cursor: pointer;
}

main > .input-section > .suggetion > .alert-mssg{
    margin-top: 30px;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.692);
}

/* end of suggetion part */

.inputs{
    width: 70%;
    height: 100%;
    margin: auto;
    margin-top: 80px;
    text-align: center;

}
.inputs .input-group  .form-control{
    height: 40px;
    box-shadow: inset 0 -1px 0 #ddd;
}

.inputs #error-msg{
    text-align: left;
    display: block;
    color: #ff1515;
    font-size: 13px;
    margin-top: 10px;
    margin-left: 10px;
    text-transform: capitalize;
}

/* .inputs input:not(#checkbox){
    width: 50%;
    height: 45px;
    border: 1px solid #ccc;
    margin-top: 20px;
    outline: none; 
    margin: auto;
} */




.inputs input::placeholder{
    font-size: 17px;
    padding-left: 20px;
    text-transform: capitalize;font-weight: inherit;
}


.inputs .message{
    margin-top: 15px;
    display: flex;
    align-items: center;
    margin-left: 25px;
}
.inputs .message input{
    width: 15px;
    height: 15px;
    margin-right: 5px;
}
.inputs .message label{
    font-size: 16px;
    font-weight: lighter;
    text-transform: capitalize;
}


.button{
    width: 120px;
    height: 35px;
    border-radius: 45px;
    margin: auto;
    margin-top: 20px;
}
.button button{
    width: 100%;
    height: 100%;
    border-radius: 45px;
    background-color: rgb(184, 179, 179);
    border: none;
    color: #fff;
}
.forgot{
    width: 100%;
    height: 50px;
    margin-top: 20px;
}
 .forgot a{
    text-decoration: none;
    font-size: 15px;
    text-transform: capitalize;

}
    </style>
</head>



<body>
    
</body>
</html>