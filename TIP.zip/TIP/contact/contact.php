<?php
error_reporting(0);
ini_set('display_errors', 0);
$name=$_POST['name'];
$email=$_POST['email'];
$topic=$_POST['topic'];
$phone=$_POST['phone'];
$message=$_POST['message'];
if($_POST['submit']){

    $conn=mysqli_connect("localhost","root","","contact");
    $query="INSERT INTO contact_details(Name,Email,,Topic,Phone,Message)VALUES('$name','$email','$topic','$phone','$message')";
    $result=mysqli_query($conn,$query);
    if($result){echo "<script>alert('Details Send Successfully')</script>";}
    else{echo "<script>alert('Some error please check')</script>";}
}


?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="contact.css">
<body>
    <nav>
        <div class="logo">tip community</div>
        <!-- end of logo div -->
        <div class="menu">
            <ul>
                <li><a href="../home_layout.php">home</a></li>
                <li><a href="">about</a></li>
                <li><a href="">blog</a></li>
                <li><a href="../contact/contact.php">contact us</a></li>
                <li><button type="button" id="signe-button"><a href="../login/login.php">Login</a></button></li>
            </ul>
        </div>
        <div class="search-button"><i class="fa fa-search" id="search"></i></div>
    </nav>
    <form method="POST" action=" ">
    <div class="main">
        <h1>Contact Us</h1>
        <input type="text" name="name" value placeholder="name" required = "required">
        <input type="Email" name="Email" value placeholder="Email" required = "required">
        <select name="topic" id="topic">
            <option value="I have a question about an innovation">I have a question about an innovation</option>
            <option value="I want to organize a HundrED Spotlight ">I want to organize a TIP Community Spotlight </option>
            <option selected="selected" value="I want to support HundrED's work">I want to support TIP Community's work</option>
            <option value="I have a media enquiry ">I have a media enquiry </option>
            <option value="Other">Other</option></select>
        <input placeholder="Phone" required="required" type="tel" name="phone" id="phone_">
        <textarea name="message" id="message" placeholder="Your message" required="required"></textarea>
        <input type="submit" value="Send" name="submit" class="button">
    </div>
    </form>
</body>
</html>
