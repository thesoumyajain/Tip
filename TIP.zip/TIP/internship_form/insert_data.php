<?php
$firstname=$_POST['FIRSTNAME'];
$lastname=$_POST['LASTNAME'];
$email=$_POST['EMAIL'];
$mobile=$_POST['MOBILE'];
$age=$_POST['AGE'];
$grade=$_POST['GRADE'];
$address=$_POST['ADDRESS'];
$introduction=$_POST['INTRO'];
$languages=$_POST['LANGUAGES'];
$responsive=$_POST['RESPONSIVE'];
$internship=$_POST['INTERNSHIP'];
if(isset($_POST['submit'])){
    
    $conn=mysqli_connect("localhost","root","","internship");
    $query="INSERT INTO datatable(FirstName,LastName,Email,Mobile,Age,Grade,Address,Introduction,Languages,Responsive,Internship) VALUES('$firstname' '$lastname' '$email' $mobile' '$age','$grade' '$address' '$introduction' '$languages' '$responsive' '$internship')";
    $result=mysqli_query($conn,$query);
    if($result){
       
        header("location:successfully_page.php");
       
    }
    else{ echo "<script>alert('Something is wrong')</script>";
    }
}


?>