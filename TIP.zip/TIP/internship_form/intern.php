
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="bootstrap.css">
 <?php include "intern_style.php"; ?>
</head>
<body>
  <header>

    <nav>
        <div class="community-heading">
            <div class="heading1">web devolapement</div>
            <div class="heading2">Freen internship in tip community</div>
        </div>
    </nav>

    <div class="message">
      Hello  <?php echo " <span id='username'>".$_SESSION['username']."</span> "; ?>   Thank you for visiting our tipcommunity.org page we 
      are providing you free internship for which you have to fill this form
    </div>
  
<div class="form-part">
  <div class="header">
    <h1>internship form</h1>
  </div>

 

  <div class="form-body">

    <div class="row" style="margin-top: 10px;">

    <form method="POST" action="insert_data.php" >
      <div class="col-12 sm-12 md-12 ">
        <label for="survay" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform: capitalize;" name="address">Full address</label>
        <input type="text"  id="survay" class="form-control" name="ADDRESS"  required="required">
      </div><!--end of colume-->
      
    </div><!--end of row1-->



      <div class="row" style="margin-top: 50px;">

      <div class="col-6 sm-8  ">
        <label for="firstname" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform: capitalize;">Student Name</label>
        <input type="text"  id="firstname" class="form-control"  required="required" placeholder="FirstName" name="FIRSTNAME">
      </div><!--end of colume-->

      
      <div class="col-6 sm-8">
        <label for="lastname" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform: capitalize;opacity: 0%;">Last Name</label>
        <input type="text"  id="lastname" class="form-control" placeholder="LastName" name="LASTNAME"  required="required">
      </div><!--end of colume-->


    </div><!--end of row2-->






    
    <div class="row" style="margin-top: 70px;">


      <div class="col-6 ">
        <label for="age" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform: capitalize;">Age</label>
        <input type="text"  id="age" class="form-control" placeholder="ex:23" name="AGE"  required="required">
      </div><!--end of colume-->

      
      <div class="col-6 ">
        <label for="grade" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform:capitalize;">Grade Level In 12th</label>
        <input type="text"  id="grade" class="form-control" placeholder="%" name="GRADE" required="required">
      </div><!--end of colume-->


    </div><!--end of row3-->





    
    <div class="row" style="margin-top: 70px;">


      <div class="col-6 ">
        <label for="mobile" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform: capitalize;">Phone Number</label>
        <input type="text"  id="mobile" class="form-control" placeholder="(000) 000-000"  required="required" name="MOBILE">
      </div><!--end of colume-->

      
      <div class="col-6 ">
        <label for="email" style="font-size: 18px;font-weight: 600; color: rgba(0, 0, 0, 0.397);padding-bottom: 13px;text-transform:capitalize;">Email</label>
        <input type="email"  id="email" class="form-control"  required="required" placeholder="exampl@gmail.com" name="EMAIL">
      </div><!--end of colume-->


    </div><!--end of row3-->

    <hr style="margin-top: 50px;width: 70%;">


    <div class="row" style="margin-top: 60px;">

      <div class="col-12">
        <p style="font-size: 17px;font-weight: 500; color: rgba(0, 0, 0, 0.801);">self introduction</p>
        <textarea  id="telent" cols="100" rows="5"  required="required" placeholder="Type Here...." name="INTRO"></textarea>
      </div>

    </div><!--end of first textarea-->

    
    <div class="row" style="margin-top: 60px;">

      <div class="col-12">
        <p style="font-size: 17px;font-weight: 500; color: rgba(0, 0, 0, 0.801);"> How many programming languages do you know?</p>
        <textarea  id="telent" cols="100" rows="5"  required="required" placeholder="Type Here...." name="LANGUAGES"></textarea>
      </div>
    </div><!--end of first textarea-->

       
    <div class="row" style="margin-top: 60px;">

      <div class="col-12">
        <p style="font-size: 17px;font-weight: 500; color: rgba(0, 0, 0, 0.801);"> give me a basic introcuction of coding</p>
        <textarea  id="telent" cols="100" rows="5"  required="required" placeholder="Type Here...."></textarea>
      </div>

    </div><!--end of first textarea-->


    <div class="row" style="margin-top: 70px;">
      <h5 style="font-weight: 500;color: rgba(0, 0, 0, 0.562);">Do you make a responsive website?</h5>
      <div class="col-10">
        <div class="form-check" style="margin-top: 15px;">
          <input class="form-check-input" type="radio" name="RESPONSIVE" id="flexRadioDefault1">
          <label class="form-check-label"  for="flexRadioDefault1">Yes</label>
        </div>
        <div class="form-check" style="margin-top: 15px;">
          <input class="form-check-input"   type="radio" name="RESPONSIVE" id="flexRadioDefault2">
          <label class="form-check-label" for="flexRadioDefault2">No</label>
        </div>
      </div>


    </div><!--end of questioning part1-->





    
    <div class="row" style="margin-top: 70px;">

      <h5 style="font-weight: 500;color: rgba(0, 0, 0, 0.562);">what is your favourite subject</h5>
      <div class="col-10">
        <div class="form-check" style="margin-top: 15px;">
          <input class="form-check-input" type="radio" name="FAVSUB" id="favsub2">
          <label class="form-check-label"  for="favsub2">coding</label>
        </div>

        <div class="form-check" style="margin-top: 15px;">

          <input class="form-check-input" type="radio"  name="FAVSUB" id="favsub2" >
          <label class="form-check-label" for="favsub2"> Dancing</label>
        </div>

        <div class="form-check" style="margin-top: 15px;">

          <input class="form-check-input"  type="radio" name="FAVSUB" id="favsub3" >
          <label class="form-check-label" for="favsub3">Sport</label>
        </div>


        <div class="form-check" style="margin-top: 15px;">

          <input class="form-check-input" type="radio" name="FAVSUB" id="4favsub" >
          <label class="form-check-label" for="4favsub">
        Problem solving
          </label>
        </div>


      </div><!--end of column -->


    </div><!--end of questioning part2 row-->








    
    <div class="row" style="margin-top: 70px;">
      <h5 style="font-weight: 500;color: rgba(0, 0, 0, 0.562);">
        have you ever intership ?</h5>
      <div class="col-10">
        <div class="form-check" style="margin-top: 15px;">
          <input class="form-check-input"   type="radio" name="INTERNSHIP" id="radio">
          <label class="form-check-label" for="radio">
       Yes
          </label>
        </div>
        <div class="form-check" style="margin-top: 15px;">
          <input class="form-check-input" type="radio" name="INTERNSHIP" id="radio2">
          <label class="form-check-label" for="radio2">
        No
          </label>
        </div>
      </div>


    </div><!--end of questioning part2-->



    <div class="row" style="margin-top: 60px;">

      <div class="col-12">
        <p style="font-size: 17px;font-weight: 500; color: rgba(0, 0, 0, 0.801);"> Is there something else you would like to share?</p>
        <textarea  id="telent"   required="required" cols="100" rows="5" placeholder="Type Here...."></textarea>
      </div>

    </div><!--end of first textarea-->

    <hr style="margin-top: 20px;margin-bottom: 20px;width: 100%;">

    <div class="row" style="margin-top: 10px;">
      <div class="col-4 offset-4">
      <button class="btn btn-success" style="width: 150px;" name="submit">Submit</button>
      </div>
    </div>

</form>
 


  </div><!--end of form body-->
  <hr style="margin-top: 20px;margin-bottom: 20px;width: 100%;">
</div><!--end of form part-->


</header>

</body>
</html>


