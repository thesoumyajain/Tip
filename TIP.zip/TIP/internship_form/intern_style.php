
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>

        
*{
    margin: 0;
    padding: 0;
}

header{
    width: 100%;
    height: 2800px;

}

header nav{
    width: 100%;height: 100px;
    box-shadow: 10px 10px 10px #eee;
    display: flex;
    align-items: center;
    justify-content: center;
}

header nav .community-heading .heading1{
    font-size: 30px;
    color:rgb(57, 3, 109);
    font-weight: 800;
    text-transform: capitalize;
    text-align: center;
    font-family: 'Shizuru', cursive;
}

header nav .community-heading .heading2{
    text-align: center;
    font-size: 18px;
    text-transform: capitalize;
}

.message{
    width: 80%;
    height: 30px;
    margin: auto;
    margin-top: 30px;
    font-size: 16px;
    text-transform: capitalize;
}


.form-part{
    width: 60%;
    height: 2370px;
   border: 1px solid rgb(13, 36, 36);
    margin-top: 70px;
    position: relative;
    margin-top: 50px;
    left: 50%;
    transform: translate(-50%);
    background-color: #fff;
   
}

.header{
    width: 100%;
    height: 150px;
    background-color:  #6c006e;

    text-align: center;
   display: flex;
   justify-content: center;
   align-items: center;
}

.header h1{
    font-size: 30px;
    color: #fff;
    text-transform: uppercase;
    font-family: Verdana, Geneva, Tahoma, sans-serif;
    letter-spacing: 1px;
}



.form-body{
    width: 90%;
    height: 2200px;
    position: relative;
    top: 20px;
    left: 50%;
    transform: translate(-50%);
    
}

#username{
    font-size:22px;font-weight:700;color:#6c006e;padding:8px 8px;text-decoration:underline;
}

    </style>
</head>
<body>
    
</body>
</html>
