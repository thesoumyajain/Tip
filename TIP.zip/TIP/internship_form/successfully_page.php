<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        header{
            width: 100%;
            height: 100vh;
            display: flex;
            align-items: center;
        }
        .section{
            width: 80%;
            height: 200px;
            margin: auto;
            padding-top: 100px;
      
        }
        .message{
            will-change: 100%;
            height: 30px;
            margin: auto;
            text-align: center;
            font-size: 18px;font-weight: lighter;color: rgba(0, 0, 0, 0.637);
        }
        .goto-button{
            width: 50%;
            height: 20px;
            margin: auto;
            text-align: center;
            margin-top: 10px;
            font-size: 18px;
        }

        

    </style>
</head>
<body>


<header>
    <section class="section">
        <div class="message">
            We have entered your information related to your internship by call or message.
            Thank you for coming to the tip community</div>
        <div class="goto-button"><a href="../home_layout.php">Go to Home</a></div>
    </section>
</header>
<!-- end of message and button section ---------------------- -->
