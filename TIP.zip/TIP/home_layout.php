<?php

session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipcommunity.com</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="home_layout.css">        
    <link rel="stylesheet" href="bootstrap.css">
    <link type="text/css" rel="stylesheet" href="css/lightslider.css" />                  
    <script src="jquery-path.js"></script>  
</head>
<body>
    
    <!-- nav bar ------------- -->
    <nav>
        <div class="logo">tip community</div>
        <!-- end of logo div -->
        <div class="menu">
            <ul>
                <li><a href="home_layout.php" ">home</a></li>
                <li><a href="#">about</a></li>
                <li><a href="#">blog</a></li>
                <li><a href="../contact/contact.php">contact us</a></li>
                <li> <button type="button" id="signe-button"><a href="login/login.php">Login</a></button></li>
            </ul>  
        </div><!--end of menus part -->

        

         <div class="search">
            <input type="text" id="text" class="form-control"><i class="fa fa-search" id="search-butt"></i>
         </div> 
         <div class="search-button"><i class="fa fa-search" id="search"></i></div> 

    </nav>
    <!-- end of navigation bar -->


    <section class="animate-background">

        <!-- <div class="search-div" id="search-div">
            <input type="search" id='search-data' class="form-control" placeholder="E.G Arts,Creativ ,Math">
        </div> -->

        <!-- end of search div -->
    </section>
        <!-- end of backgoround div  -->
          
    <div class="letest-news-div">

        <div class="heading">The latest 
            <div class="numbers">
                <ul>
                <li><h5 class="num active">1</h5></li>
                <li><h5 class="num">2</h5></li>
                <li><h5 class="num">3</h5></li>
                </ul>


            </div><!--end of numbers div-->
        </div><!--end of heading -->


        <!-- --------------------------------------------------------------------------------- -->
        <!-- -------------------------------------------------- -->
        <div class="news-container">

        <div class="news-row" id="news-row">

        <!-- start letest new column -->
        <div class="content-div">
            <div class="video-section">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/XbIXxDMeRGA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <!-- end of video section -->
            
            <div class="information-section">

                <h1>watch Sustainable Development Goals  Zero Hunger</h1>

                 <p>Sustainable Development Goal 2 aims to achieve "zero hunger". It is one of the 17 
                     Sustainable Development Goals established by the United Nations in 2015.
                      The official wording is: "End hunger, achieve food security and improved 
                     nutrition and promote sustainable agriculture</p>

                      <button id="watch-video">watch now</button>

            </div><!-- end of information div -->
            </div><!-- end of content div -->
            <!--------------------end of content div/column-------------------->



            <!-- start letest new column -->
        <div class="content-div">
            <div class="video-section">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/e2S9wf5oVT4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <!-- end of video section -->
            
            <div class="information-section">

                <h1>watch 17 Sustainable Development Goals</h1>

                 <p>The 17 Sustainable Development Goals (SDGs), with their 169 targets,
                      form the core of the 2030 Agenda. They balance the economic, social and 
                      ecological dimensions of sustainable development, and place the fight against
                      poverty and sustainable development on the same </p><br>

                      <button id="watch-video">watch now</button>

            </div><!-- end of information div -->
            </div><!-- end of content div -->
            <!--------------------end of content div/column-------------------->





            <!-- start letest new column -->
        <div class="content-div">
            <div class="video-section">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/XbIXxDMeRGA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <!-- end of video section -->
            
            <div class="information-section">

                <h1> What is Sustainability?</h1>

                 <p>In an effort to to educate more people and businesses who are
                      interested in sustainability and minimizing their environmental impact so 
                      they can protect what they love, we have created a new blog and video series
                       called, "Sustainability 101."  The first in the series answers the question,
                        "What is Sustainability?"
                </p><br><br>

                <button id="watch-video">watch now</button>


            </div><!-- end of information div -->
         
            </div><!-- end of content div -->
            <!--------------------end of content div/column-------------------->


        <!--------------------------------------------------------------------->
            </div><!--end of row-->
        </div>
        <!-- ------------------------------------------------------------------>   
    </div><!-- end of letest new div -->

    <!-- The Latest Articles-->

    <section class="articles-section">
        <div class="article-heading"><h2>The Latest Articles</h2></div>

        <div class="articles">
                <!----------------------------------- -->
                <div class="card" style="width: 19rem;height: 33rem;">
                    <img src="photos/article1-img.jpeg" class="card-img-top">
                    <div class="card-body">
                     <h5>ARTILES</h5>
                      <h4><a href="">8 Education Innovations Tackling the Climate Crisis</a></h4><br><br>
                      <p>The UN Climate Change Conference in Glasgow (COP26) last month brought together 120 world leaders and over</p>
                      <h6>COMMUNITY PARTNERSHIPS CRISIS EDUCATION STUDENT VOICE AND AGENCY SUSTAINABILITY</h6>
                      <div class="button">view</div>
                    </div><!--end of card body-->
                </div><!--end of card -->
                <!---------------------------------------->

                    <!----------------------------------- -->
                    <div class="card" style="width: 19rem;height: 33rem;">
                        <img src="photos/article2-img.png" class="card-img-top">
                        <div class="card-body">
                         <h5>ARTILES</h5>
                          <h4><a href="">Meet The HundrED Team: Crystal Green, Head of Research</a></h4>
                          <p>Learn more about HundrED Head of Research, Crystal Green. Crystal is currently a postdoctoral scholar at the University of tip community ... </p>
                          <h6>COMMUNITY PARTNERSHIPS CRISIS EDUCATION STUDENT VOICE AND AGENCY SUSTAINABILITY</h6>
                          <div class="button">view</div>
                        </div><!--end of card body-->
                    </div><!--end of card -->
                    <!---------------------------------------->


                        <!----------------------------------- -->
                <div class="card" style="width: 19rem;height: 33rem;">
                    <img src="photos/article3-img.jpeg" class="card-img-top">
                    <div class="card-body">
                     <h5>ARTILES</h5>
                      <h4><a href="">How Can We Support a World in Which Children Are Free to Become Engaged... </a></h4>
                      <p>In light of the COVID-19 pandemic, we need to support students' social and emotional development  But...</p><br>
                      <h6>COMMUNITY PARTNERSHIPS CRISIS EDUCATION STUDENT VOICE AND AGENCY SUSTAINABILITY</h6>
                      <div class="button">view</div>
                    </div><!--end of card body-->
                </div><!--end of card -->
                <!---------------------------------------->

                <div class="card" style="width: 19rem;height: 33rem;">
                    <img src="photos/article4-img.jpeg" class="card-img-top" height="195px">
                    <div class="card-body">
                     <h5>ARTILES</h5>
                      <h4><a href="">Country Lead Nathan Strenge on his Search for a more Purpose Driven Life ...</a></h4>
                      <p>HundrED Country Lead, Nathan Strenge shares insights into his own life and passion for innovation in education as we...</p><br>
                      <h6>COMMUNITY PARTNERSHIPS CRISIS EDUCATION STUDENT VOICE AND AGENCY SUSTAINABILITY</h6>
                      <div class="button">view</div>
                    </div><!--end of card body-->
                </div><!--end of card -->
                <!---------------------------------------->

                    <!----------------------------------- -->
                 


            




        </div><!--end of articles section-->
        <!-- show all articles button -->
            <div class="show-all-button"><button>Show all Articles</button></div>
</section><!--end of articles section-->

<!-- end of article section --------------------------------------------------- -->

<section class="community-intro">
    
    <div class="video-template" id="video-template">
        <i class="fa fa-times" id="close"></i>
        <div>
        <iframe width="620px" height="350px" src="https://www.youtube.com/embed/0XTBYMfZyrM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        </div>
    </div>
    <div class="introduction">
<div>
        <h1>what is tip community ?</h1>
        <h5>We are a global community of great thinkers and young 
            enthusiastic people working on educating people about 
            17 UNSDGs using our unique approach of using creative tools
             and combining young passion with greatest ideas.</h5>

             <div class="buttons">
                 <button id="video"><i class="fa fa-play"></i> video</button>
                 <button id="FAQ">FAQ</button>
                 <button id="menifesto">menifesto</button>
             </div>
</div>
    </div>
    <!--end of introduction part-->
    
</section>
<!-- end of community introduction section -->

<!-- ---------------------company logos section---------------------->
<section class="company-logos-section">

    <h2>our partners</h2>
    <p>Our work is supported by our global and project partners.</p>
    <div class="company-logos">
        <img src="photos/logo1.svg">
        <img src="photos/log2.svg">
        <img src="photos/logo3.svg">
        <img src="photos/logo4.svg">
        <img src="photos/logo5.svg">
    </div><!--end of company logos-->
    
</section><!--end of company logo section-->
          
<!-- ---------------------------footer section coding --------------------------------- -->
<footer class="footer">

 <div class="part1">

<div class="menus">
  <h5>important information</h5>
  <ul>
    <li><a href="#">about tip</a></li>
    <li><a href="#">blog</a></li>
    <li><a href="#">contact</a></li>
</ul>
</div><!--end of menus-->

<div class="social-links">
    <h3>social media</h3>
    <ul>
        <li><a href=""><i class="fa fa-facebook"></i></a></li>
        <li><a href=""><i class="fa fa-twitter"></i></a></li>
        <li><a href=""><i class="fa fa-instagram"></i></a></li>
        <li><a href=""><i class="fa fa-linkedin"></i></a></li>
    </ul>
</div>

</div><!--end of part1-->
<hr style="width: 90%;color: #fff;">

<!-- end of part 1 -->

<div class="part2">
        <h2>tipcommunity </h2>
       <p>© 2021 Tip Community.org. All rights reserved</p>
</div>



</footer>


<!-- link js file -->

<script src="home_layout.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/lightslider.js"></script>


<!-- <script src="lightslider.js"></script> -->


</body>
</html>