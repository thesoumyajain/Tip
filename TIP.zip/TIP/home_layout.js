// start java script code 
// accesing search button
 var search=document.getElementById("search");
 var search_div=document.getElementById("search-div");
 var video=document.getElementById("video");
 var video_template=document.getElementById("video-template");
 var close=document.getElementById("close");
 var num=document.getElementsByClassName("num");
 var slide=document.getElementById("news-row")
 var search_box=document.getElementById("text");
 var search_butt=document.getElementById("search-butt")

//  start searching box coding
search_box.addEventListener("input",function(){
    search_butt.style.color="blue";
});

search.addEventListener("click",function(){

    search_div.classList.toggle("active-div")
  
 });


//  video hoverin code

video.addEventListener("click",function(){
    video_template.style.display='block';
});



close.addEventListener("click",function(){
    video_template.style.display='none';
});




//  start sideshow of letest news jquery code
// letest news section coding

num[0].addEventListener("click",function(){

    slide.style.transform='translateX(0px)';

    for(let i=0;i<3;i++){
        num[i].classList.remove("active");
    }
    this.classList.add("active");

});

num[1].addEventListener("click",function(){

    slide.style.transform='translateX(-1300px)';

    for(let i=0;i<3;i++){
        num[i].classList.remove("active");
    }
    this.classList.add("active");

});


num[2].addEventListener("click",function(){

    slide.style.transform='translateX(-2600px)';

    for(let i=0;i<3;i++){
        num[i].classList.remove("active");
    }
    this.classList.add("active");

});

// end of letest new sliding section